﻿using System;
namespace NationalInstruments.Examples.RFSA
{
    static class Program
    {
        static void Main(string[] args)
        {
            RFSAGettingStartedSpectrumExample RFSAStartedSpectrum = new RFSAGettingStartedSpectrumExample();
            RFSAStartedSpectrum.Run();
        }
    }
}
