NotInheritable Class Program
	Private Sub New()
	End Sub
	Friend Shared Sub Main(args As String())
		Dim RFSAStartedSpectrum As New RFSAGettingStartedSpectrumExample()
		RFSAStartedSpectrum.Run()
	End Sub
End Class
