﻿using System;
namespace NationalInstruments.Examples.RFSA
{
    static class Program
    {
        static void Main(string[] args)
        {
            RFSAStartedIQExample RFSAStartedIQ = new RFSAStartedIQExample();
            RFSAStartedIQ.Run();
        }
    }
}
