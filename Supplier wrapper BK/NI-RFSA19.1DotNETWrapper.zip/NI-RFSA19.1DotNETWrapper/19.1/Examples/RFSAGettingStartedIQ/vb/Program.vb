NotInheritable Class Program
	Private Sub New()
	End Sub
	Friend Shared Sub Main(args As String())
		Dim RFSAStartedIQ As New RFSAStartedIQExample()
		RFSAStartedIQ.Run()
	End Sub
End Class
