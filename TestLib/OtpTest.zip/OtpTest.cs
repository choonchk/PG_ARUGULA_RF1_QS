﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Windows.Forms;
using EqLib;
using ClothoLibAlgo;
using Avago.ATF.StandardLibrary;
using Avago.ATF.Shares;
using Avago.ATF.Logger;
using Avago.ATF.LogService;
using System.Diagnostics;
using WSD.Utility.OtpModule;
using System.Threading;

namespace TestLib
{


    public abstract class OtpTest : TimingBase, iTest
    {
        public bool Initialize(bool finalScript)
        {
            InitializeTiming2(this.TestCon.TestParaName);
            //Eq.Site[Site].HSDIO.AddVectorsToScript(TestCon.MipiCommands, finalScript);
            Initialize();//Initialize OtpModuleSerialTest/OtpMfgLotNumTest
            m_dupResultDetector = new DuplicateDetector();
            return true;
        }

        private DuplicateDetector m_dupResultDetector;
        public byte Site;
        public OtpTestConditions TestCon = new OtpTestConditions();
        public OtpTestResults TestResult;
        //public Dictionary<string, string> OTP_Register_Definitions = new Dictionary<string, string>();//***************************************************************************************************************



        public int RunTest()
        {
            try
            {
                TestResult = new OtpTestResults();

                if (ResultBuilder.headerFileMode) return 0;

                SwBeginRun();

                EqHSDIO.dutSlaveAddress = TestCon.SlaveAddr;

                this.ConfigureVoltageAndCurrent();
                //Eq.Site[Site].HSDIO.SendNextVectors(false, TestCon.MipiCommands);

                SwStartRun("HSDIO.Reset");
                Eq.Site[Site].HSDIO.SendVector(EqHSDIO.Reset);
                SwStopRun("HSDIO.Reset");
                //Eq.Site[Site].DC["Vbatt"].ForceVoltage(3.4, 0.01);
                //Eq.Site[Site].DC["Vio"].ForceVoltage(0, 0.01);
                //Eq.Site[Site].DC["Vio"].ForceVoltage(1.8, 0.01);
                //EqHSDIO.dutSlaveAddress = TestCon.dutSlaveAdd;
                //string readback = Eq.Site[Site].HSDIO.RegRead("E6");
                //otpBurnProcedure.Burn(Site, "E5", "CF");

                //otpBurnProcedure.Burn(Site, "E6", "C0");
                //string readback2 = Eq.Site[Site].HSDIO.RegRead("E5");
                RunTestCore();
                SwEndRun();

                return 0;
            }
            catch (Exception e)
            {
                MessageBox.Show("Error happened during RunTest in TestLib.cs" + "\r\n" + e.ToString());

                return 0;
            }
        }

        public abstract void RunTestCore();
        public abstract void Initialize();
        public void BuildResults(ref ATFReturnResult results)
        {

            switch (TestCon.TestType.ToUpper())
            {
                case "OTP_BURN_LNA":
                {
                    m_dupResultDetector.Add(Site, TestCon.TestParaName + "_ERROR", "", TestResult.NumBitErrors, 4);
                    TestResult.NumBitErrors = 0;
                    break;
                }

                case "OTP_BURN_MOD_ID":
                {
                    m_dupResultDetector.Add(Site, TestCon.TestParaName.Replace("MOD", "MODULE") + "_ERROR", "", TestResult.NumBitErrors, 4);
                    TestResult.NumBitErrors = 0;
                    break;
                }

                case "OTP_BURN_REV_ID":
                {
                    m_dupResultDetector.Add(Site, TestCon.TestParaName + "_ERROR", "", TestResult.NumBitErrors, 4);
                    TestResult.NumBitErrors = 0;
                    break;
                }

                case "OTP_BURN_LOCK_BIT":
                {
                    m_dupResultDetector.Add(Site, TestCon.TestParaName.Replace("LOCK_BIT", "LOCKBIT") + "_ERROR", "", TestResult.NumBitErrors, 4);
                    TestResult.NumBitErrors = 0;
                    break;
                }

                case "OTP_BURN_FBAR_NOISE_PASS_FLAG":
                {
                    m_dupResultDetector.Add(Site, TestCon.TestParaName.Replace("FBAR_NOISE_PASS_FLAG", "FBAR-NOISE-PASS-FLAG") + "_ERROR", "", TestResult.NumBitErrors, 4);
                    TestResult.NumBitErrors = 0;
                    break;
                }

                case "OTP_BURN_NFR_PASS_FLAG":
                {
                    m_dupResultDetector.Add(Site, TestCon.TestParaName.Replace("NFR_PASS_FLAG", "NFR-PASS-FLAG") + "_ERROR", "", TestResult.NumBitErrors, 4);
                    TestResult.NumBitErrors = 0;
                    break;
                }

                case "OTP_BURN_RF1_PASS_FLAG":
                {
                    m_dupResultDetector.Add(Site, TestCon.TestParaName.Replace("RF1_PASS_FLAG", "RF1-PASS-FLAG") + "_ERROR", "", TestResult.NumBitErrors, 4);
                    TestResult.NumBitErrors = 0;
                    break;
                }

                case "OTP_BURN_CUSTOM":
                    {
                        m_dupResultDetector.Add(Site, TestCon.TestParaName + "_ERROR", "", TestResult.NumBitErrors, 4);
                        TestResult.NumBitErrors = 0;
                        break;
                    }

                case "OTP_READ_MOD_ID":
                {
                    m_dupResultDetector.Add(Site, "OTP_MODULE_ID", "", TestResult.Module_ID, 4);
                    break;
                }

                case "OTP_READ_CM_ID":
                {
                    m_dupResultDetector.Add(Site, "M_MIPI_CM-ID", "", TestResult.CM_ID, 4);
                    break;
                }

                case "OTP_READ_MFG_ID":
                {
                    m_dupResultDetector.Add(Site,  "MFG_ID", "", TestResult.MFG_ID, 1);
                    break;
                }

                case "OTP_READ_LOCK_BIT":
                {
                    m_dupResultDetector.Add(Site, "M_" + "OTP_LOCKBIT_STATUS", "", Convert.ToDouble(TestResult.Lock_Bit), 1, TestCon.RequiresDataCheckFirst);
                    break;
                }

                case "OTP_READ_FBAR_NOISE_PASS_FLAG":
                {
                    m_dupResultDetector.Add(Site, "M_" + "OTP_FBAR-NOISE-FLAG_STATUS", "", Convert.ToDouble(TestResult.FBAR_Noise_Pass_Flag), 1, TestCon.RequiresDataCheckFirst);
                    break;
                }

                case "OTP_READ_NFR_PASS_FLAG":
                {
                    m_dupResultDetector.Add(Site, "M_" + "OTP_NFR-FLAG_STATUS", "", Convert.ToDouble(TestResult.FBAR_Noise_Pass_Flag), 1, TestCon.RequiresDataCheckFirst);
                    break;
                }

                case "OTP_READ_RF1_PASS_FLAG":
                {
                    m_dupResultDetector.Add(Site, "M_" + "OTP_RF1-PA-FLAG_STATUS", "", Convert.ToDouble(TestResult.RF1_Pass_Flag), 1, TestCon.RequiresDataCheckFirst);
                    break;
                }

                case "OTP_READ_RF2_PASS_FLAG":
                {
                    m_dupResultDetector.Add(Site, "M_" + "OTP_RF2-SPARA-FLAG_STATUS", "", Convert.ToDouble(TestResult.RF2_Pass_Flag), 1, TestCon.RequiresDataCheckFirst);
                    break;
                }

                case "OTP_READ_REV_ID":
                {
                    m_dupResultDetector.Add(Site, "M_" + "OTP_REV_ID", "", TestResult.REV_ID, 1);
                    break;
                }

                case "OTP_READ_TX_X":
                    {
                        m_dupResultDetector.Add(Site, "MIPI_CMOS-TX-X", "", TestResult.TX_X, 1);
                        break;
                    }

                case "OTP_READ_TX_Y":
                    {
                        m_dupResultDetector.Add(Site, "MIPI_CMOS-TX-Y", "", TestResult.TX_Y, 1);
                        break;
                    }

                case "OTP_READ_WAFER_LOT":
                    {
                        m_dupResultDetector.Add(Site, "MIPI_CMOS-TX-WAFER-LOT", "", TestResult.WAFER_LOT, 1);
                        break;
                    }

                case "OTP_READ_WAFER_ID":
                    {
                        m_dupResultDetector.Add(Site, "MIPI_CMOS-TX-WAFER-ID", "", TestResult.WAFER_ID, 1);
                        break;
                    }

                case "OTP_READ_LNA_X":
                    {
                        m_dupResultDetector.Add(Site, "MIPI_LNA-X", "", TestResult.LNA_X, 1);
                        break;
                    }

                case "OTP_READ_LNA_Y":
                    {
                        m_dupResultDetector.Add(Site, "MIPI_LNA-Y", "", TestResult.LNA_Y, 1);
                        break;
                    }

                case "OTP_READ_LNA_WAFER_LOT":
                    {
                        m_dupResultDetector.Add(Site, "MIPI_LNA-WAFER-LOT", "", TestResult.LNA_WAFER_LOT, 1);
                        break;
                    }

                case "OTP_READ_LNA_WAFER_ID":
                    {
                        m_dupResultDetector.Add(Site, "MIPI_LNA-WAFER-ID", "", TestResult.LNA_WAFER_ID, 1);
                        break;
                    }

                case "OTP_READ_BYTES": //20190709 new OtpTest
                    {
                        m_dupResultDetector.Add(Site,  TestCon.TestParaName, "", TestResult.ReadBytes, 1);
                        break; 
                    }

                case "OTP_CHECK_BIT": //20190709 new OtpTest
                    {
                        m_dupResultDetector.Add(Site, TestCon.TestParaName, "", Convert.ToDouble(TestResult.CheckBit) , 1);
                        break;
                    }

                case "OTP_MOD_ID_SELECT":
                {
                    m_dupResultDetector.Add(Site, TestCon.TestParaName.Replace("MOD", "MODULE") + "-FLAG", "", TestResult.Mod_ID_Flag, 1);
                    break;
                }
            }
        }



        private void ConfigureVoltageAndCurrent()
        {
            foreach (string pinName in TestCon.DcSettings.Keys)
            {
                if (Eq.Site[Site].HSDIO.IsMipiChannel(pinName.ToUpper())) continue; // don't force voltage on MIPI pins

                string msg = String.Format("ForceVoltage on pin {0}", pinName);
                SwStartRun(msg);
                Eq.Site[Site].DC[pinName].ForceVoltage(TestCon.DcSettings[pinName].Volts, TestCon.DcSettings[pinName].Current);
                SwStopRun(msg);
            }
        }
    }

    public class OtpTestConditions
    {
        public string TestParaName;
        public string SlaveAddr;
        public Dictionary.Ordered<string, DcSetting> DcSettings = new Dictionary.Ordered<string, DcSetting>();
        public List<MipiSyntaxParser.ClsMIPIFrame> MipiCommands;
        public string Module_ID_to_Burn;
        public string MFG_ID_to_Burn;
        public string REV_ID_to_Burn;
        public string TestType;
        public bool InitTest = false;
        public bool RequiresDataCheckFirst = false;
    }

    public class OtpTestResults
    {
        //public int ExpectedValue;
        //public int ReadValue;
        public int Mod_ID_Flag;  //used to bin out specific parts to Bin one if the Mod_ID matched a list from TCF
        public int NumBitErrors;
        public bool BurnPass;
        //public int ModuleID_burned;
        //public int MfgID_Burned;

        public int ReadBytes;
        public bool CheckBit;

        public int Module_ID;
        public int CM_ID;
        public int MFG_ID;
        public int REV_ID;
        public int TX_X, TX_Y, WAFER_LOT, WAFER_ID;
        public int LNA_X, LNA_Y, LNA_WAFER_LOT, LNA_WAFER_ID;
        public bool FBAR_Noise_Pass_Flag;
        public bool RF1_Pass_Flag;
        public bool RF2_Pass_Flag;
        public bool Lock_Bit;
    }

    public class OtpBurnTest : OtpTest
    {
        public override void Initialize()
        {

        }
        public override void RunTestCore()
        {
            string msg = "RunTestCore-" + TestCon.TestType.ToUpper();
            SwStartRun(msg);
            bool doBurn = ResultBuilder.FailedTests[Site].Count == 0;

            EqHSDIO.dutSlaveAddress = TestCon.SlaveAddr;
            

            if (doBurn) 
            {
                switch (TestCon.TestType.ToUpper())
                {
                    case "OTP_BURN_LNA":

                        if (TestCon.InitTest)   // do not burn OTP during Init Test
                            break;
                        else
                            TestResult.NumBitErrors = OTP_Procedure.OTP_Burn_LNA(Site);
                        break;

                    case "OTP_BURN_MOD_ID":

                        if (TestCon.InitTest)   // do not burn OTP during Init Test
                            break;
                        else
                            //TestResult.NumBitErrors = OTP_Procedure.OTP_Burn_Mod_ID(Site, TestCon.MFG_ID_to_Burn, TestCon.Module_ID_to_Burn);
                            TestResult.NumBitErrors = OTP_Procedure.OTP_Burn_Mod_ID2(Site, TestCon.MipiCommands, TestCon.MFG_ID_to_Burn, TestCon.Module_ID_to_Burn);
                        break;

                    case "OTP_BURN_REV_ID":

                        if (TestCon.InitTest)   // do not burn OTP during Init Test
                            break;
                        else
                            TestResult.NumBitErrors = OTP_Procedure.OTP_Burn_Rev_ID(Site, TestCon.REV_ID_to_Burn);
                        break;

                    case "OTP_BURN_FBAR_NOISE_PASS_FLAG":
                    case "OTP_BURN_NFR_PASS_FLAG":

                        if (TestCon.InitTest)   // do not burn OTP during Init Test
                            break;
                        else
                            TestResult.NumBitErrors = OTP_Procedure.OTP_Burn_FBAR_Noise_Pass_Flag(Site);
                        break;


                    case "OTP_BURN_RF1_PASS_FLAG":

                        if (TestCon.InitTest)   // do not burn OTP during Init Test
                            break;
                        else
                            TestResult.NumBitErrors = OTP_Procedure.OTP_Burn_RF1_Pass_Flag(Site);
                        break;

                    case "OTP_BURN_RF2_PASS_FLAG":

                        if (TestCon.InitTest)   // do not burn OTP during Init Test
                            break;
                        else
                            TestResult.NumBitErrors = OTP_Procedure.OTP_Burn_RF2_Pass_Flag(Site);
                        break;

                    case "OTP_BURN_LOCK_BIT":

                        if (TestCon.InitTest)   // do not burn OTP during Init Test
                            break;
                        else
                            TestResult.NumBitErrors = OTP_Procedure.OTP_Burn_Lock_Bit(Site);
                        break;

                    case "OTP_BURN_CUSTOM": //20190709 New Otptest

                        if (TestCon.InitTest)   // do not burn OTP during Init Test
                            break;
                        else
                            TestResult.NumBitErrors = OTP_Procedure.OTP_Burn_Custom(Site, TestCon.MipiCommands);
                        break;


                    default:
                        MessageBox.Show("Warning: UnKnown OTP Test Type:" + TestCon.TestType.ToUpper() + "Check Spelling", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;

                }
            }

            SwStopRun(msg);

        }
    }


    public class OtpReadTest : OtpTest
    {
        public override void Initialize()
        {

        }
        public override void RunTestCore()
        {
            EqHSDIO.dutSlaveAddress = TestCon.SlaveAddr;

            string msg = "RunTestCore-" + TestCon.TestType.ToUpper();
            SwStartRun(msg);

            switch (TestCon.TestType.ToUpper())
            {
                case "OTP_READ_BYTES": //20190709 new OtpTest
                    TestResult.ReadBytes = OTP_Procedure.OTP_Read_Bytes(Site,TestCon.MipiCommands);
                    break;

                case "OTP_CHECK_BIT": //20190709 new OtpTest
                    TestResult.CheckBit = OTP_Procedure.OTP_Check_Bit(Site, TestCon.MipiCommands);
                    break;

                case "OTP_READ_MOD_ID":
                    TestResult.Module_ID = OTP_Procedure.OTP_Read_Mod_ID(Site);
                    break;

                case "OTP_READ_CM_ID":
                    TestResult.CM_ID = OTP_Procedure.OTP_Read_CM_ID(Site) == true? 1 : 0;
                    break;

                case "OTP_READ_MFG_ID":

                    TestResult.MFG_ID = OTP_Procedure.OTP_Read_MFG_ID(Site);
                    break;

                case "OTP_READ_LOCK_BIT":

                    TestResult.Lock_Bit = OTP_Procedure.OTP_Read_Lock_Bit(Site);
                    break;

                case "OTP_READ_FBAR_NOISE_PASS_FLAG":
                case "OTP_READ_NFR_PASS_FLAG":

                    TestResult.FBAR_Noise_Pass_Flag = OTP_Procedure.OTP_Read_FBAR_Noise_Pass_Flag(Site);
                    break;

                case "OTP_READ_RF1_PASS_FLAG":

                    TestResult.RF1_Pass_Flag = OTP_Procedure.OTP_Read_RF1_Pass_Flag(Site);
                    break;

                case "OTP_READ_RF2_PASS_FLAG":

                    TestResult.RF2_Pass_Flag = OTP_Procedure.OTP_Read_RF2_Pass_Flag(Site);
                    break;

                case "OTP_READ_REV_ID":

                    TestResult.REV_ID = OTP_Procedure.OTP_Read_Rev_ID(Site); 
                    break;

                case "OTP_READ_TX_X":

                    TestResult.TX_X = OTP_Procedure.OTP_Read_TX_X(Site);
                    break;

                case "OTP_READ_TX_Y":

                    TestResult.TX_Y = OTP_Procedure.OTP_Read_TX_Y(Site);
                    break;

                case "OTP_READ_WAFER_LOT":

                    TestResult.WAFER_LOT = OTP_Procedure.OTP_Read_WAFER_LOT(Site);
                    break;

                case "OTP_READ_WAFER_ID":

                    TestResult.WAFER_ID = OTP_Procedure.OTP_Read_WAFER_ID(Site);
                    break;

                case "OTP_READ_LNA_X":

                    TestResult.LNA_X = OTP_Procedure.OTP_Read_LNA_X(Site);
                    break;

                case "OTP_READ_LNA_Y":

                    TestResult.LNA_Y = OTP_Procedure.OTP_Read_LNA_Y(Site);
                    break;

                case "OTP_READ_LNA_WAFER_LOT":

                    TestResult.LNA_WAFER_LOT = OTP_Procedure.OTP_Read_LNA_WAFER_LOT(Site);
                    break;

                case "OTP_READ_LNA_WAFER_ID":

                    TestResult.LNA_WAFER_ID = OTP_Procedure.OTP_Read_LNA_WAFER_ID(Site);
                    break;

                case "OTP_MOD_ID_SELECT":

                    TestResult.Mod_ID_Flag = OTP_Procedure.OTP_ModID_Select(Site);
                    break;

                default:
                    MessageBox.Show("Warning: UnKnown OTP Test Type:" + TestCon.TestType.ToUpper() + "Check Spelling", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
            SwStopRun(msg);
        }

    }

    public static class OTP_Procedure
    {
        public static string mfg_id_str = "-999999";
        // public static Dictionary<string, string> OTP_Register_Definitions;
        public static string LNA_OTP_Revision = "";

        public static Dictionary<int, List<int>> ModuleIDSelect = new Dictionary<int, List<int>>(); // used to store list of mod_IDs of parts to Bin out. List comes from TCF
        public static bool EnableModuleIDselect = false;

        public static bool EnableOTPburnTemplate = false;

        public static int OTP_Burn_LNA(int Site)
        {
            Stopwatch myWatch = new Stopwatch();
            myWatch.Start();

            int OTP_Burn_failure_Count = -999999;
            bool VerifyPassed = false;

            Eq.Site[Site].HSDIO.SendVector("VIOOFF");
            Thread.Sleep(5);

            Eq.Site[Site].HSDIO.SendVector("VIOON");
            Thread.Sleep(5);

            Eq.Site[Site].DC["Vlna"].ForceVoltage(2.5, .1);

            // check if previously burned
            VerifyPassed = Eq.Site[Site].HSDIO.SendVector("RXOTPVERIFYREV" + LNA_OTP_Revision);
            OTP_Burn_failure_Count = Eq.Site[Site].HSDIO.GetNumExecErrors("RXOTPVERIFYrev" + LNA_OTP_Revision);

            if (VerifyPassed)  // no bit errors means the part was already burned
            {
                OTP_Burn_failure_Count = -999999;
                return OTP_Burn_failure_Count;
            }


            Thread.Sleep(5);
            Eq.Site[Site].HSDIO.SendVector("RXOTPBURNREV" + LNA_OTP_Revision);
            Thread.Sleep(5);


            Eq.Site[Site].DC["Vlna"].ForceVoltage(1.8, 0.1);


            Eq.Site[Site].HSDIO.SendVector("VIOOFF");
            Thread.Sleep(5);

            Eq.Site[Site].HSDIO.SendVector("VIOON");
            Thread.Sleep(5);


            Thread.Sleep(5);
            //OTP_Burn_failure_Count = Eq.Site[Site].HSDIO.SendVector_Return_Error_Count("RXOTPVERIFY");
            Convert.ToUInt16(Eq.Site[Site].HSDIO.SendVector("RXOTPVERIFYrev" + LNA_OTP_Revision));
            OTP_Burn_failure_Count = Eq.Site[Site].HSDIO.GetNumExecErrors("RXOTPVERIFYrev" + LNA_OTP_Revision);

            Thread.Sleep(5);

            myWatch.Stop();
            double testtime = myWatch.ElapsedMilliseconds;


            return OTP_Burn_failure_Count;
        }



        public static int OTP_Burn_Mod_ID(int Site, string mfg_id_specified = "", string mod_id_specified = "")
        {
            if (true)
            //if (FailedTests.Count == 0)   // for Proto-3, turn-on during EVT
            {


                #region HSDIO Sendvector

                int ReadData_Mfg_ID = -999999;
                bool ReadData_Lock_Bit = false;
                int ReadData_Mod_ID = -999999;

                int MFG_ID = -999999;
                int ModuleID = 0;


                //Read_Unit_Number = 0;

                ReadData_Mfg_ID = OTP_Read_MFG_ID(Site);

                ReadData_Lock_Bit = OTP_Read_Lock_Bit(Site);

                ReadData_Mod_ID = OTP_Read_Mod_ID(Site);


                if (ReadData_Mfg_ID != 0 || ReadData_Mod_ID != 0 || ReadData_Lock_Bit != false) // if already burned
                {
                    return -999999; // return if any OTP already burned
                }



                if ((mfg_id_specified != "") || (mod_id_specified != ""))  // If higher level code specifies these optional parameters then don't use the sever to get MFG_ID and MOD_ID
                {

                    MFG_ID = Int32.Parse(mfg_id_specified);
                    ModuleID = Int32.Parse(mod_id_specified);
                }
                else
                {
                    /********************************************************* Not for use in Penang Production MFT and MOD ID will be done at wafer level or specifed as above ***********************************************************************************************************************************/
                    /* New serial id query that returns _otp_unit_id */

                    // Two approach of reading mfg_id
                    // (a) If already burnt in EEPROM, read from there by h/w API. 
                    // (b) Not available in EEPROM, need scan into Clotho MainUI and read from Cross Domain Cache. 
                    // For our cases, follow Option (b) 

                    // Read mfg_id from Cross Domain Cache 
                    // NOTE at this moment, MFG_ID is string for Clotho; Need parse to int so Clotho can write into result file
                    // In the future Clotho will upgrade to directly handle MFG_ID as int

                    string err = "";

                    // get and convert MFG_ID from Clotho to an int
                    if (mfg_id_str != "1")  // "1" means Mod_ID was not specified in Clotho and we set static mfg_id_str to default "0"
                        mfg_id_str = ATFCrossDomainWrapper.GetStringFromCache(PublishTags.PUBTAG_MFG_ID, "");

                    //int MFG_ID = -999999;
                    try
                    {
                        MFG_ID = Int32.Parse(mfg_id_str);

                    }
                    catch (Exception ex2)
                    {
                        MessageBox.Show("Invalid MFG_ID was entered. 1 will be used as default", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        mfg_id_str = "1"; // will retain this value for future parts so message doesnt keep poping up
                        MFG_ID = 1;
                    }


                    if (MFG_ID > 65535)
                    {
                        MessageBox.Show("Requested MFG_ID: " + MFG_ID.ToString() + " is larger than OTP register capacity", "Exit Test Plan Run, MFT_ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return -999999;
                    }

                    // Now that valid mfg_id is ready, get Module ID
                    try
                    {
                        Tuple<bool, int, string> unique_id_ret = SerialProvider.GetNextModuleID(MFG_ID);

                        if (!unique_id_ret.Item1)
                        {
                            err = unique_id_ret.Item3;
                            MessageBox.Show("Module ID Server is not responding. Fix or Disable Module ID burn in TCF. \n\n" + err, "Exit Test Plan Run", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return -999999;
                        }
                        else
                        {
                            ModuleID = unique_id_ret.Item2;
                        }
                    }

                    catch
                    { // ID Server may be down
                        MessageBox.Show("Exit Test Plan Run, Module ID Server is not responding. Disable Module ID burn in TCF\n\n" + err, "Exit Test Plan Run", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        throw;
                    }

                    /*****************************************************************************************************************************************************************************************************/
                }






                Eq.Site[Site].DC["Vbatt"].ForceVoltage(5.5, .1);


                /* Program Module (serial) ID */
                if (ModuleID > 16382)
                {
                    MessageBox.Show("Issued Module ID: " + Convert.ToString(ModuleID) + " is larger than OTP register capacity", "Exit Test Plan Run, Module_ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return 0;
                }



                int NumOfBits = Convert.ToInt16(Eq.Site[Site].HSDIO.Get_Digital_Definition("MOD_ID_NUM_BITS"));
                string[] bitVectors = new string[NumOfBits];

                for (int bit = 0; bit < NumOfBits; bit++)
                {
                    bitVectors[bit] = Eq.Site[Site].HSDIO.Get_Digital_Definition("MOD_ID_BIT" + Convert.ToString(bit));
                }

                char[] mod_id_char = (Convert.ToString(Convert.ToInt32(ModuleID), 2).PadLeft(NumOfBits, '0')).ToCharArray();  //convert to Binary string 
                System.Array.Reverse(mod_id_char);

                int vectorIndex = 0;
                foreach (char Value in mod_id_char)
                {
                    if (Value == '1')
                    {
                        string temp = bitVectors[vectorIndex];
                        Eq.Site[Site].HSDIO.SendVector(bitVectors[vectorIndex]);
                    }
                    vectorIndex++;
                }


                /* Program MFG ID */

                if (MFG_ID > 65535)
                {
                    MessageBox.Show("Requested MFG_ID: " + MFG_ID.ToString() + " is larger than OTP register capacity", "Exit Test Plan Run, MFT_ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -999999;
                }

                bitVectors = null;
                NumOfBits = Convert.ToInt16(Eq.Site[Site].HSDIO.Get_Digital_Definition("MFG_ID_NUM_BITS"));
                bitVectors = new string[NumOfBits];

                for (int bit = 0; bit < NumOfBits; bit++)
                {
                    bitVectors[bit] = Eq.Site[Site].HSDIO.Get_Digital_Definition("MFG_ID_BIT" + Convert.ToString(bit));
                }

                char[] mfg_id_char = (Convert.ToString(Convert.ToInt32(MFG_ID), 2).PadLeft(16, '0')).ToCharArray();  //convert to Binary string 
                System.Array.Reverse(mfg_id_char);

                vectorIndex = 0;
                foreach (char Value in mfg_id_char)
                {
                    if (Value == '1')
                    {
                        Eq.Site[Site].HSDIO.SendVector(bitVectors[vectorIndex]);
                    }
                    vectorIndex++;
                }



                Eq.Site[Site].DC["Vbatt"].ForceVoltage(3.8, 0.1);

                // reset VIO and verify burn
                Eq.Site[Site].HSDIO.SendVector("VIOOFF");
                Thread.Sleep(5);

                Eq.Site[Site].HSDIO.SendVector("VIOON");
                Thread.Sleep(5);


                //verify burn successful 
                if (ModuleID != OTP_Read_Mod_ID(Site) || MFG_ID != OTP_Read_MFG_ID(Site))
                {
                    return 1;
                }
                else
                    return 0;


            }

            #endregion

        }

        public static int OTP_Burn_Mod_ID2(int Site, List<MipiSyntaxParser.ClsMIPIFrame> MipiCommands, string mfg_id_specified = "", string mod_id_specified = "")
        {
            if (true)
            //if (FailedTests.Count == 0)   // for Proto-3, turn-on during EVT
            {
                
                #region HSDIO Sendvector
                
                int MFG_ID = -999999;
                int ModuleID = 0;
                                              
                try { mod_id_specified = Convert.ToString(ATFCrossDomainWrapper.GetClothoCurrentSN()); }
                catch { mod_id_specified = "258"; } //Debug Mode


                if ((mfg_id_specified != "") || (mod_id_specified != ""))  // If higher level code specifies these optional parameters then don't use the sever to get MFG_ID and MOD_ID
                {
                    MFG_ID = Int32.Parse(mfg_id_specified);
                    ModuleID = Int32.Parse(mod_id_specified);
                }
                else
                {
                    /********************************************************* Not for use in Penang Production MFT and MOD ID will be done at wafer level or specifed as above ***********************************************************************************************************************************/
                    /* New serial id query that returns _otp_unit_id */

                    // Two approach of reading mfg_id
                    // (a) If already burnt in EEPROM, read from there by h/w API. 
                    // (b) Not available in EEPROM, need scan into Clotho MainUI and read from Cross Domain Cache. 
                    // For our cases, follow Option (b) 

                    // Read mfg_id from Cross Domain Cache 
                    // NOTE at this moment, MFG_ID is string for Clotho; Need parse to int so Clotho can write into result file
                    // In the future Clotho will upgrade to directly handle MFG_ID as int

                    string err = "";

                    // get and convert MFG_ID from Clotho to an int
                    if (mfg_id_str != "1")  // "1" means Mod_ID was not specified in Clotho and we set static mfg_id_str to default "0"
                        mfg_id_str = ATFCrossDomainWrapper.GetStringFromCache(PublishTags.PUBTAG_MFG_ID, "");

                    //int MFG_ID = -999999;
                    try
                    {
                        MFG_ID = Int32.Parse(mfg_id_str);

                    }
                    catch (Exception ex2)
                    {
                        MessageBox.Show("Invalid MFG_ID was entered. 1 will be used as default", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        mfg_id_str = "1"; // will retain this value for future parts so message doesnt keep poping up
                        MFG_ID = 1;
                    }


                    if (MFG_ID > 65535)
                    {
                        MessageBox.Show("Requested MFG_ID: " + MFG_ID.ToString() + " is larger than OTP register capacity", "Exit Test Plan Run, MFT_ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return -999999;
                    }

                    // Now that valid mfg_id is ready, get Module ID
                    try
                    {
                        Tuple<bool, int, string> unique_id_ret = SerialProvider.GetNextModuleID(MFG_ID);

                        if (!unique_id_ret.Item1)
                        {
                            err = unique_id_ret.Item3;
                            MessageBox.Show("Module ID Server is not responding. Fix or Disable Module ID burn in TCF. \n\n" + err, "Exit Test Plan Run", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return -999999;
                        }
                        else
                        {
                            ModuleID = unique_id_ret.Item2;
                        }
                    }

                    catch
                    { // ID Server may be down
                        MessageBox.Show("Exit Test Plan Run, Module ID Server is not responding. Disable Module ID burn in TCF\n\n" + err, "Exit Test Plan Run", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        throw;
                    }

                    /*****************************************************************************************************************************************************************************************************/
                }
                                
                /* Program Module (serial) ID */
                if (ModuleID > 32767)
                {
                    MessageBox.Show("Issued Module ID: " + Convert.ToString(ModuleID) + " is larger than OTP register capacity", "Exit Test Plan Run, Module_ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return 0;
                }

                
                /* Program MFG ID */

                if (MFG_ID > 65535)
                {
                    MessageBox.Show("Requested MFG_ID: " + MFG_ID.ToString() + " is larger than OTP register capacity", "Exit Test Plan Run, MFT_ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -999999;
                }
                
                //re-set with Clotho PID * MFG
                foreach (MipiSyntaxParser.ClsMIPIFrame temp in MipiCommands)
                {
                    switch(temp.Register_hex)
                    {
                        case "0":
                            int Reg0 = (MFG_ID & 0xff00) >> 8;
                                MipiCommands[0].Data_hex = Reg0.ToString("X");
                                break;
                        case "1":
                            int Reg1 = MFG_ID & 0xff;
                            MipiCommands[1].Data_hex = Reg1.ToString("X");
                            break;
                        case "4":
                            int Reg4 = (ModuleID & 0xff00) >> 8;
                            MipiCommands[2].Data_hex = Reg4.ToString("X");
                            break;
                        case "5":
                            int Reg5 = ModuleID & 0xff;
                            MipiCommands[3].Data_hex = Reg5.ToString("X");
                            break;
                        default:
                            MessageBox.Show("Resigtor " + temp.Register_hex  + "is not for Mod_id and Mfg_ID", "Exit Test Plan Run", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                    }
                }

                List<string> All_bitVectors = new List<string>();
                string Projectspecific = "PINOT";

                foreach (MipiSyntaxParser.ClsMIPIFrame temp in MipiCommands)
                {
                    EqHSDIO.selectorMipiPair(temp.Pair);

                    string _Register_Hex = "";

                    if (temp.Pair == 1)
                        _Register_Hex = "TX_EFUSE_BYTE" + temp.Register_hex;
                    else
                        _Register_Hex = "RX_EFUSE_BYTE" + temp.Register_hex;

                    _Register_Hex = Eq.Site[Site].HSDIO.Get_Digital_Definition(_Register_Hex);

                    if (OTP_Check_Bit2(Site, _Register_Hex, temp.Data_hex) != false) //if already burned
                    {
                        return -999999; // return if any OTP already burned
                    }

                    All_bitVectors.AddRange(Vectorselector(Site, temp));
                }
                All_bitVectors.RemoveAll(s => s == null);


                PreOTPstage(Site, Projectspecific, EqHSDIO.dutSlavePairIndex);

                if (EnableOTPburnTemplate)
                {
                    Eq.Site[Site].HSDIO.SendMipiCommands(MipiCommands, eMipiTestType.OTPburn);
                }
                else
                {
                    foreach (string strvector in All_bitVectors)
                    {
                        Eq.Site[Site].HSDIO.SendVector(strvector);
                    }
                }

                PostOTPstage(Site, Projectspecific, EqHSDIO.dutSlavePairIndex);

                foreach (MipiSyntaxParser.ClsMIPIFrame temp in MipiCommands)
                {
                    string Dietype = temp.Pair == 1 ? "TX" : "RX";
                    string Register_hex2 = Eq.Site[Site].HSDIO.Get_Digital_Definition(Dietype + "_EFUSE_BYTE" + temp.Register_hex);
                    int readbackOTP = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Register_hex2), 16) & Convert.ToInt32(temp.Data_hex, 16);
                    if (readbackOTP != Convert.ToInt32(temp.Data_hex, 16)) return 0;
                }

                return 1;
            }

            #endregion

        }

        public static int OTP_Burn_Rev_ID(int Site, string rev_id_specified)
        {
            if (true)
            {


                #region HSDIO Sendvector

                int ReadData = -999999;
                if (rev_id_specified == "")
                {
                    return -999999; // return if no rev specified
                }
                try
                {
                    ReadData = OTP_Read_Rev_ID(Site);
                }
                catch (Exception e)
                {

                    ReadData = 888888;
                }


                if (ReadData != 0) // if already burned
                {
                    if (ReadData == 888888) return 888888;
                    return -999999; // return if any OTP already burned
                }



                Eq.Site[Site].DC["Vbatt"].ForceVoltage(5.5, .1);



                /* Program Rev ID */

                int NumOfBits = Convert.ToInt16(Eq.Site[Site].HSDIO.Get_Digital_Definition("REV_ID_NUM_BITS"));
                string[] bitVectors = new string[NumOfBits];

                for (int bit = 0; bit < NumOfBits; bit++)
                {
                    bitVectors[bit] = Eq.Site[Site].HSDIO.Get_Digital_Definition("REV_ID_BIT" + Convert.ToString(bit));
                }

                char[] rev_id_char = (Convert.ToString(Convert.ToInt32(rev_id_specified), 2).PadLeft(NumOfBits, '0')).ToCharArray();  //convert to Binary string 
                System.Array.Reverse(rev_id_char);

                int vectorIndex = 0;
                foreach (char Value in rev_id_char)
                {
                    if (Value == '1')
                    {
                        string temp = bitVectors[vectorIndex];
                        Eq.Site[Site].HSDIO.SendVector(bitVectors[vectorIndex]);
                    }
                    vectorIndex++;
                }



                Eq.Site[Site].DC["Vbatt"].ForceVoltage(3.8, 0.1);

                ///reset VIO and verify burn
                Eq.Site[Site].HSDIO.SendVector("VIOOFF");
                Thread.Sleep(5);

                Eq.Site[Site].HSDIO.SendVector("VIOON");
                Thread.Sleep(5);


                //verify burn successful  and otp lock
                if (Convert.ToInt32(rev_id_specified) != OTP_Read_Rev_ID(Site))
                {
                    return 1;
                }
                else
                    return 0;
            }

            #endregion

        }

        public static int OTP_Burn_Lock_Bit(int Site)
        {
            if (true)   // do not OTP during Init Test
            {


                #region HSDIO Sendvector


                if (OTP_Read_Lock_Bit(Site) == true) // if already burned
                {
                    return -999999; // return if any OTP already burned
                }

                Eq.Site[Site].DC["Vbatt"].ForceVoltage(5.5, .1);


                //Burn OTP lock bit lock 
                Eq.Site[Site].HSDIO.SendVector(Eq.Site[Site].HSDIO.Get_Digital_Definition("LOCK_BIT_BURN"));

                Eq.Site[Site].DC["Vbatt"].ForceVoltage(3.8, 0.1);

                // reset VIO and verify burn
                Eq.Site[Site].HSDIO.SendVector("VIOOFF");
                Thread.Sleep(5);

                Eq.Site[Site].HSDIO.SendVector("VIOON");
                Thread.Sleep(5);


                //verify burn successful  
                if (OTP_Read_Lock_Bit(Site) != true)
                {
                    return 1;
                }
                else
                    return 0;
            }

            #endregion

        }

        public static int OTP_Burn_FBAR_Noise_Pass_Flag(int Site)
        {
            if (true)   // do not OTP during Init Test
            {


                #region HSDIO Sendvector

                if (OTP_Read_FBAR_Noise_Pass_Flag(Site) == true) // if already burned
                {
                    return -999999; // return if any OTP already burned
                }

                Eq.Site[Site].DC["Vbatt"].ForceVoltage(5.5, .1);


                //Burn FBAR PAss flag
                Eq.Site[Site].HSDIO.SendVector(Eq.Site[Site].HSDIO.Get_Digital_Definition("FBAR_FLAG_BURN"));

                Eq.Site[Site].DC["Vbatt"].ForceVoltage(3.8, 0.1);

                // reset VIO and verify burn
                Eq.Site[Site].HSDIO.SendVector("VIOOFF");
                Thread.Sleep(5);

                Eq.Site[Site].HSDIO.SendVector("VIOON");
                Thread.Sleep(5);


                //verify burn successful 
                if (OTP_Read_FBAR_Noise_Pass_Flag(Site) != true)
                {
                    return 1;
                }
                else
                    return 0;
            }

            #endregion

        }

        public static int OTP_Burn_RF1_Pass_Flag(int Site)
        {
            if (true)   // do not OTP during Init Test
            {


                #region HSDIO Sendvector


                if (OTP_Read_RF1_Pass_Flag(Site) != false) // if already burned
                {
                    return -999999; // return if any OTP already burned
                }

                Eq.Site[Site].DC["Vbatt"].ForceVoltage(5.5, .1);


                //Burn RF1 Pass flag
                //Eq.Site[Site].HSDIO.SendVector(Eq.Site[Site].HSDIO.Get_Digital_Definition("RF1_FLAG_BURN"));

                #region MIPI OTP

                string bit_location = Eq.Site[Site].HSDIO.Get_Digital_Definition("RF1_FLAG_BURN");
                string[] bit_info = bit_location.Split(new char[] { '_' }, StringSplitOptions.RemoveEmptyEntries);

                if (bit_info.Length > 2)
                {
                    int register = int.Parse(bit_info[1].ToUpper().Replace("E", ""));
                    int bit_number = int.Parse(bit_info[2].ToUpper().Replace("B", ""));
                    Eq.Site[Site].HSDIO.RegWrite("2B", "0F");
                    Eq.Site[Site].HSDIO.Burn((1 << bit_number).ToString("X"), false, register);
                    Eq.Site[Site].HSDIO.RegWrite("1C", "40");
                    Eq.Site[Site].HSDIO.SendVector("VIOOFF");
                    Thread.Sleep(1);
                    Eq.Site[Site].HSDIO.SendVector("VIOON");
                    Eq.Site[Site].HSDIO.RegWrite("2B", "0F");

                    Eq.Site[Site].DC["Vbatt"].ForceVoltage(0, 0.0001);
                    Thread.Sleep(10);
                    Eq.Site[Site].DC["Vbatt"].ForceVoltage(5.5, 0.2);
                }
                #endregion

                Eq.Site[Site].DC["Vbatt"].ForceVoltage(3.8, 0.1);

                // reset VIO and verify burn
                Eq.Site[Site].HSDIO.SendVector("VIOOFF");
                Thread.Sleep(5);

                Eq.Site[Site].HSDIO.SendVector("VIOON");
                Thread.Sleep(5);



                //verify burn successful  
                if (OTP_Read_RF1_Pass_Flag(Site) != true)
                {
                    return 1;
                }
                else
                    return 0;
            }

            #endregion
        }

        public static int OTP_Burn_RF2_Pass_Flag(int Site)
        {
            if (true)   // do not OTP during Init Test
            {


                #region HSDIO Sendvector


                if (OTP_Read_RF2_Pass_Flag(Site) != false) //if already burned
                {
                    return -999999; // return if any OTP already burned
                }

                Eq.Site[Site].DC["Vbatt"].ForceVoltage(5.5, .1);


                //Burn FBAR PAss flag
                Eq.Site[Site].HSDIO.SendVector(Eq.Site[Site].HSDIO.Get_Digital_Definition("RF2_FLAG_BURN"));

                Eq.Site[Site].DC["Vbatt"].ForceVoltage(3.8, 0.1);

                // reset VIO and verify burn
                Eq.Site[Site].HSDIO.SendVector("VIOOFF");
                Thread.Sleep(5);

                Eq.Site[Site].HSDIO.SendVector("VIOON");
                Thread.Sleep(5);



                //verify burn successful  
                if (OTP_Read_RF2_Pass_Flag(Site) != true)
                {
                    return 1;
                }
                else
                    return 0;
            }

            #endregion
        }
                

        public static int OTP_Burn_Custom(int Site, List<MipiSyntaxParser.ClsMIPIFrame> MipiCommands)   //20190709 new OtpTest
        {
            List<string> All_bitVectors = new List<string>();
            string Projectspecific = "PINOT";

            foreach (MipiSyntaxParser.ClsMIPIFrame temp in MipiCommands)
            {
                EqHSDIO.selectorMipiPair(temp.Pair);

                string _Register_Hex = "";

                if (temp.Pair==1)
                    _Register_Hex = "TX_EFUSE_BYTE" + temp.Register_hex;
                else
                    _Register_Hex = "RX_EFUSE_BYTE" + temp.Register_hex;

                _Register_Hex = Eq.Site[Site].HSDIO.Get_Digital_Definition(_Register_Hex);

                if (OTP_Check_Bit2(Site, _Register_Hex, temp.Data_hex) != false) //if already burned
                {
                    return -999999; // return if any OTP already burned
                }

                All_bitVectors.AddRange(Vectorselector(Site, temp));
            }
            All_bitVectors.RemoveAll(s => s == null);
            

            PreOTPstage(Site,Projectspecific, EqHSDIO.dutSlavePairIndex);

            if (EnableOTPburnTemplate)
            {
                Eq.Site[Site].HSDIO.SendMipiCommands(MipiCommands, eMipiTestType.OTPburn);
            }
            else
            {
                foreach (string strvector in All_bitVectors)
                {
                    Eq.Site[Site].HSDIO.SendVector(strvector);
                }
            }

            PostOTPstage(Site, Projectspecific, EqHSDIO.dutSlavePairIndex);
            
            foreach (MipiSyntaxParser.ClsMIPIFrame temp in MipiCommands)
            {
                string Dietype = temp.Pair == 1 ? "TX" : "RX";
                string Register_hex2 = Eq.Site[Site].HSDIO.Get_Digital_Definition(Dietype + "_EFUSE_BYTE" + temp.Register_hex);
                int readbackOTP = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Register_hex2), 16) & Convert.ToInt32(temp.Data_hex, 16);
                if (readbackOTP != Convert.ToInt32(temp.Data_hex, 16)) return 0;                    
            }          
            
            return 1;
        }
      
        public static int OTP_Read_Bytes(int site, List<MipiSyntaxParser.ClsMIPIFrame> MipiCommands)    //20190709 new OtpTest
        {
            int calculatedResult = 0;

            int[] Arryreadcustom = new int[MipiCommands.Count];
            int count = 0;
            string _Register_Hex = "";

            foreach (MipiSyntaxParser.ClsMIPIFrame _temp in MipiCommands)
            {
                EqHSDIO.selectorMipiPair(_temp.Pair);

                if (_temp.Pair == 1)
                    _Register_Hex = "TX_EFUSE_BYTE" + _temp.Register_hex;
                else
                    _Register_Hex = "RX_EFUSE_BYTE" + _temp.Register_hex;

                _Register_Hex = Eq.Site[site].HSDIO.Get_Digital_Definition(_Register_Hex);

                Arryreadcustom[count] = Convert.ToInt32(Eq.Site[site].HSDIO.RegRead(_Register_Hex), 16) & Convert.ToInt32(_temp.Data_hex, 16);
                count++;
            }

            count = 0;

            foreach (int tempResult in Arryreadcustom)
            {                
                calculatedResult += (int)(tempResult * Math.Pow(256, count));
                count++;
            }
                       

            return calculatedResult;
        }

        public static bool OTP_Check_Bit(int site, List<MipiSyntaxParser.ClsMIPIFrame> MipiCommands) //20190709 new OtpTest
        {
            int calculatedResult = -999999;
            bool isburn = false;
            int countData = 0;

            int intData = Int32.Parse(MipiCommands[0].Data_hex, System.Globalization.NumberStyles.HexNumber);
            char[] Data_char = (Convert.ToString(intData, 2).PadLeft(8, '0')).ToCharArray();  //convert to Binary string                        

            foreach (char Value in Data_char)
            {
                if (Value == '1')   countData++;
            }

            if (MipiCommands.Count>1 || countData != 1)
            {
                MessageBox.Show("More than one bit check is not supported", "OTP Check Bit Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            string _Register_Hex = "";

            if (MipiCommands[0].Pair == 1)
                _Register_Hex = "TX_EFUSE_BYTE" + MipiCommands[0].Register_hex;
            else
                _Register_Hex = "RX_EFUSE_BYTE" + MipiCommands[0].Register_hex;

            _Register_Hex = Eq.Site[site].HSDIO.Get_Digital_Definition(_Register_Hex);

            calculatedResult = Convert.ToInt32(Eq.Site[site].HSDIO.RegRead(_Register_Hex), 16) & Convert.ToInt32(MipiCommands[0].Data_hex, 16);
            isburn = calculatedResult > 0 ? true : false;

            return isburn; 
        }

        private static bool OTP_Check_Bit2(int site, string Register_hex, string Data_hex) //20190709 new OtpTest
        {
            int calculatedResult = -999999;
            bool isburn = false;            

            calculatedResult = Convert.ToInt32(Eq.Site[site].HSDIO.RegRead(Register_hex), 16) & Convert.ToInt32(Data_hex, 16);
            isburn = calculatedResult > 0 ? true : false;

            return isburn;
        }

        public static int OTP_Read_Mod_ID(int Site)
        {
            int Module_ID = -999999;
            int ReadData_MSB = -999999;
            int ReadData_LSB = -999999;
            int NumOfBits = 0;

            NumOfBits = Convert.ToInt32(Eq.Site[Site].HSDIO.Get_Digital_Definition("MOD_ID_NUM_BITS"));

            ReadData_LSB = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("MOD_ID_LSB_READ")),16);
            if (NumOfBits > 8)
            {
                ReadData_MSB = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("MOD_ID_MSB_READ")), 16);
                Module_ID = (ReadData_MSB * 256) + ReadData_LSB; 
            }
            else
                Module_ID = ReadData_LSB;

            //Mask only number of bits in case pass Flags share register
            Module_ID = MaskOtherBits(Module_ID, NumOfBits);

            return Module_ID;
        }

        public static int OTP_Read_MFG_ID(int Site)
        {
            int MFG_ID = -999999;
            int ReadData_MSB = -999999;
            int ReadData_LSB = -999999;
            int NumOfBits = 0;

            NumOfBits = Convert.ToInt32(Eq.Site[Site].HSDIO.Get_Digital_Definition("MFG_ID_NUM_BITS"));

            ReadData_LSB = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("MFG_ID_LSB_READ")), 16);

            if (NumOfBits > 8)
            { 
                ReadData_MSB = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("MFG_ID_MSB_READ")), 16);
                MFG_ID = (ReadData_MSB * 256) + ReadData_LSB;
            }
            else
                MFG_ID = ReadData_LSB;

            //Mask only number of bits in case pass Flags share register
            MFG_ID = MaskOtherBits(MFG_ID, NumOfBits);

            return MFG_ID;
        }

        public static bool OTP_Read_CM_ID(int Site)
        {
            int ReadData = -999999;

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("CM_ID_READ")), 16);


            return checkBitValue(ReadData, Eq.Site[Site].HSDIO.Get_Digital_Definition("CM_ID"));

        }

        public static bool OTP_Read_Lock_Bit(int Site)
        {
            int ReadData = -999999;

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("LOCK_BIT_READ")),16);


            return checkBitValue(ReadData, Eq.Site[Site].HSDIO.Get_Digital_Definition("LOCK_BIT_BURN"));

        }


        public static bool OTP_Read_FBAR_Noise_Pass_Flag(int Site)
        {
            int ReadData = -999999;

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("FBAR_FLAG_READ")),16);


            return checkBitValue(ReadData, Eq.Site[Site].HSDIO.Get_Digital_Definition("FBAR_FLAG_BURN"));

        }

        public static bool OTP_Read_Noise_Pass_Flag(int Site)
        {
            int ReadData = -999999;

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("NOISE_FLAG_READ")), 16);


            return checkBitValue(ReadData, Eq.Site[Site].HSDIO.Get_Digital_Definition("NOISE_FLAG_BURN"));
        }

        public static bool OTP_Read_RF1_Pass_Flag(int Site)
        {
            int ReadData = -999999;

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("RF1_FLAG_READ")),16);

            return checkBitValue(ReadData, Eq.Site[Site].HSDIO.Get_Digital_Definition("RF1_FLAG_BURN"));
        }

        //ChoonChin - DPAT passflag
        public static bool OTP_Read_DPAT_Pass_Flag(int Site)
        {
            int ReadData = -999999;

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("DPAT_FLAG_READ")), 16);


            return checkBitValue(ReadData, Eq.Site[Site].HSDIO.Get_Digital_Definition("DPAT_FLAG_BURN"));
        }


        public static bool OTP_Read_RF2_Pass_Flag(int Site)
        {
            int ReadData = -999999;

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("RF2_FLAG_READ")), 16);

            return checkBitValue(ReadData, Eq.Site[Site].HSDIO.Get_Digital_Definition("RF2_FLAG_BURN"));
        }

        public static int OTP_Read_TX_X(int Site)
        {
            int TX_X = -999999;
            int ReadData = -999999;
            int NumOfBits = 0;

            NumOfBits = Convert.ToInt32(Eq.Site[Site].HSDIO.Get_Digital_Definition("CMOS_TX_X_NUM_BITS"));

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("CMOS_TX_X_READ")), 16);

            TX_X = ReadData;

            //Mask only number of bits in case pass Flags share register
            TX_X = MaskOtherBits(TX_X, NumOfBits);

            return TX_X;
        }

        public static int OTP_Read_TX_Y(int Site)
        {
            int TX_Y = -999999;
            int ReadData = -999999;
            int NumOfBits = 0;

            NumOfBits = Convert.ToInt32(Eq.Site[Site].HSDIO.Get_Digital_Definition("CMOS_TX_Y_NUM_BITS"));

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("CMOS_TX_Y_READ")), 16);

            TX_Y = ReadData;

            //Mask only number of bits in case pass Flags share register
            TX_Y = MaskOtherBits(TX_Y, NumOfBits);

            return TX_Y;
        }

        public static int OTP_Read_WAFER_LOT(int Site)
        {
            int WAFER_LOT = -999999;
            int ReadData_MSB = -999999;
            int ReadData_LSB = -999999;
            int NumOfBits = 0;

            NumOfBits = Convert.ToInt32(Eq.Site[Site].HSDIO.Get_Digital_Definition("CMOS_TX_WAFER_LOT_NUM_BITS"));

            ReadData_LSB = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("CMOS_TX_WAFER_LOT_LSB_READ")), 16);

            if (NumOfBits > 8)
            {
                ReadData_MSB = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("CMOS_TX_WAFER_LOT_MSB_READ")), 16);
                WAFER_LOT = (ReadData_MSB * 256) + ReadData_LSB;
            }
            else
                WAFER_LOT = ReadData_LSB;

            //Mask only number of bits in case pass Flags share register
            WAFER_LOT = MaskOtherBits(WAFER_LOT, NumOfBits);

            return WAFER_LOT;
        }

        public static int OTP_Read_WAFER_ID(int Site)
        {
            int WAFER_ID = -999999;
            int ReadData = -999999;
            int NumOfBits = 0;

            NumOfBits = Convert.ToInt32(Eq.Site[Site].HSDIO.Get_Digital_Definition("CMOS_TX_WAFER_ID_NUM_BITS"));

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("CMOS_TX_WAFER_ID_READ")), 16);

            WAFER_ID = ReadData;

            //Mask only the first 6 MSB Bits
            //WAFER_ID = (WAFER_ID & 252) >> 2;
            WAFER_ID = (WAFER_ID >> 2) & (int)(Math.Pow(2, NumOfBits) - 1);

            return WAFER_ID;
        }

        public static int OTP_Read_LNA_X(int Site)
        {
            int LNA_X = -999999;
            int ReadData = -999999;
            int NumOfBits = 0;

            NumOfBits = Convert.ToInt32(Eq.Site[Site].HSDIO.Get_Digital_Definition("LNA_X_NUM_BITS"));

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("LNA_X_READ")), 16);

            LNA_X = ReadData;

            //Mask only number of bits in case pass Flags share register
            LNA_X = MaskOtherBits(LNA_X, NumOfBits);

            return LNA_X;
        }

        public static int OTP_Read_LNA_Y(int Site)
        {
            int LNA_Y = -999999;
            int ReadData = -999999;
            int NumOfBits = 0;

            NumOfBits = Convert.ToInt32(Eq.Site[Site].HSDIO.Get_Digital_Definition("LNA_Y_NUM_BITS"));

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("LNA_Y_READ")), 16);

            LNA_Y = ReadData;

            //Mask only number of bits in case pass Flags share register
            LNA_Y = MaskOtherBits(LNA_Y, NumOfBits);

            return LNA_Y;
        }

        public static int OTP_Read_LNA_WAFER_LOT(int Site)
        {
            int LNA_WAFER_LOT = -999999;
            int ReadData_MSB = -999999;
            int ReadData_LSB = -999999;
            int NumOfBits = 0;

            NumOfBits = Convert.ToInt32(Eq.Site[Site].HSDIO.Get_Digital_Definition("LNA_WAFER_LOT_NUM_BITS"));

            ReadData_LSB = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("LNA_WAFER_LOT_LSB_READ")), 16);

            if (NumOfBits > 8)
            {
                ReadData_MSB = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("LNA_WAFER_LOT_MSB_READ")), 16);
                LNA_WAFER_LOT = (ReadData_MSB * 256) + ReadData_LSB;
            }
            else
                LNA_WAFER_LOT = ReadData_LSB;

            //Mask only number of bits in case pass Flags share register
            LNA_WAFER_LOT = MaskOtherBits(LNA_WAFER_LOT, NumOfBits);

            return LNA_WAFER_LOT;
        }

        public static int OTP_Read_LNA_WAFER_ID(int Site)
        {
            int LNA_WAFER_ID = -999999;
            int ReadData = -999999;
            int NumOfBits = 0;

            NumOfBits = Convert.ToInt32(Eq.Site[Site].HSDIO.Get_Digital_Definition("LNA_WAFER_ID_NUM_BITS"));

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("LNA_WAFER_ID_READ")), 16);

            LNA_WAFER_ID = ReadData;

            //Mask only the first 6 MSB Bits
            //LNA_WAFER_ID = (LNA_WAFER_ID & 252) >> 2;
            LNA_WAFER_ID = (LNA_WAFER_ID >> 2) & (int)(Math.Pow(2, NumOfBits) - 1);

            return LNA_WAFER_ID;
        }

        public static int OTP_Read_Rev_ID(int Site)
        {
            int REV_ID = -999999;
            int ReadData = -999999;
            int NumOfBits = 0;

            NumOfBits = Convert.ToInt32(Eq.Site[Site].HSDIO.Get_Digital_Definition("REV_ID_NUM_BITS"));

            ReadData = Convert.ToInt32(Eq.Site[Site].HSDIO.RegRead(Eq.Site[Site].HSDIO.Get_Digital_Definition("REV_ID_READ")),16); 

            REV_ID = ReadData;

            //Mask only number of bits in case pass Flags share register
            REV_ID = MaskOtherBits(REV_ID, NumOfBits);

            return REV_ID;
        }

        
        public static int OTP_ModID_Select(int Site)
        {
            int Selected = -999999;
            int MFG_ID = OTP_Read_MFG_ID(Site);
            int MOD_ID = OTP_Read_Mod_ID(Site);
            if (ModuleIDSelect.ContainsKey(MFG_ID))

                if (ModuleIDSelect[MFG_ID].Contains(MOD_ID))
                    Selected = 0;//Find selected Mod_ID and MFG_ID

            return Selected;
        }



        public static int MaskOtherBits(int Data, int NumOfBits)
        {
            int Mask = 0;

            for (int i = 0; i < NumOfBits; i++)
            {
                Mask |= (1 << i);
            }
            Data = Data & Mask;

            return Data;
        }

        public static bool checkBitValue(int Data, String Bitlocation)
        {
            string[] BitNumber = Bitlocation.Split(new char[] { 'B' }, StringSplitOptions.RemoveEmptyEntries);

            int Mask = (1 << Convert.ToInt32(BitNumber[BitNumber.Length - 1]));
            int Value = Data & Mask;

            if (Value == Mask)
                return true;
            else
                return false;
        }

        private static string[] Vectorselector(int Site, MipiSyntaxParser.ClsMIPIFrame _temp)  //20190709 new OtpTest
        {
            try
            {
                string Dietype = _temp.Pair == 1 ? "TX" : "RX";
                int Bitcount = 0;

                int intData = Int32.Parse(_temp.Data_hex, System.Globalization.NumberStyles.HexNumber);
                char[] Data_char = (Convert.ToString(intData, 2).PadLeft(8, '0')).ToCharArray();  //convert to Binary string                        
                string[] bitVectors = new string[Data_char.Length];
                System.Array.Reverse(Data_char);
                foreach (char Value in Data_char)
                {
                    if (Value == '1')
                        bitVectors[Bitcount] = "S" + _temp.SlaveAddress_hex + "_" +
                                     Eq.Site[Site].HSDIO.Get_Digital_Definition(Dietype + "_EFUSE_BYTE" + _temp.Register_hex) + "_" +
                                     "B" + Convert.ToString(Bitcount);

                    Bitcount++;
                }
                return bitVectors;
            }
            catch (Exception e)
            {
                MessageBox.Show("Error happened during Vectorselector in Otpburn" + "\r\n" + e.ToString());
                return null;
            }
        }  

        private static void PreOTPstage(int Site, string _Proejct, int _dutSlavePairIndex)  //20190709 new OtpTest
        {
            if (_dutSlavePairIndex == 2)
            {
                switch (_Proejct)
                {
                    case "PINOT":
                        EnableOTPburnTemplate = true;
                        Eq.Site[Site].DC["Vdd"].ForceVoltage(1.2, 0.1);
                        Eq.Site[Site].HSDIO.RegWrite("F0", "00");
                        Eq.Site[Site].HSDIO.RegWrite("F0", "C0");

                        break;

                    default: break;
                }
            }
            else
            {
                switch (_Proejct)
                {
                    case "PINOT":
                        EnableOTPburnTemplate = true;
                        Eq.Site[Site].DC["Vbatt"].ForceVoltage(5.5, .1);
                        Eq.Site[Site].HSDIO.RegWrite("2B", "0F");

                        break;

                    default: break;
                }
            }
        }   

        private static void PostOTPstage(int Site, string _Proejct, int _dutSlavePairIndex) //20190709 new OtpTest
        {
            if (_dutSlavePairIndex == 2)
            {
                switch (_Proejct)
                {
                    case "PINOT":
                        Eq.Site[Site].HSDIO.RegWrite("F0", "20");
                        Eq.Site[Site].HSDIO.RegWrite("F0", "10");

                        Eq.Site[Site].DC["Vdd"].ForceVoltage(0, 0.0001);
                        Eq.Site[Site].HSDIO.SendVector("VIOOFF");
                        Thread.Sleep(1);
                        Eq.Site[Site].HSDIO.SendVector("VIOON");
                        Thread.Sleep(1);
                        break;

                    default: break;
                }
            }
            else
            {
                switch (_Proejct)
                {
                    case "PINOT":
                        Eq.Site[Site].HSDIO.RegWrite("1C", "40");
                        Eq.Site[Site].HSDIO.SendVector("VIOOFF");
                        Thread.Sleep(1);
                        Eq.Site[Site].HSDIO.SendVector("VIOON");
                        Eq.Site[Site].HSDIO.RegWrite("2B", "0F");

                        Eq.Site[Site].DC["Vbatt"].ForceVoltage(0, 0.0001);
                        Thread.Sleep(10);
                        Eq.Site[Site].DC["Vbatt"].ForceVoltage(5.5, 0.2);
                        Thread.Sleep(1);
                        break;

                    default: break;
                }
            }

        }   

    }

    /// <summary>
    /// Ensure no duplicate result. Update the result value if there's duplicate.
    /// </summary>
    public class DuplicateDetector
    {
        public void Add(byte site, string testName, string units, double rawResult, byte decimalPlaces = byte.MaxValue,
            bool skipSpecCheck = false)
        {
            bool isNotExist = !ResultBuilder.ParametersDict.ContainsKey(testName);
            if (isNotExist)
            {
                ResultBuilder.AddResult(site, testName, "", rawResult, 1, skipSpecCheck);
                return;
            }

            // Update the value.
            int index = ResultBuilder.results.Data.FindIndex(x => x.Name == testName);
            List<double> r = ResultBuilder.results.Data[index].Vals;
            while (r.Count < site + 1)
            {
                r.Add(double.NaN);
            }

            r[site] = rawResult;
        }
    }

}